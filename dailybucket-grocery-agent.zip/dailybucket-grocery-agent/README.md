# DailyBucket Grocery Support Agent

A website page that embeds a Jotform AI support agent for an online grocery store, plus the data files used to train it.

## Project structure

```
.
├── index.html                       Page that embeds the Jotform agent
├── data/
│   ├── grocery_catalog.csv          45 sample products (prices in INR)
│   ├── agent_qa_pairs.csv           84 example questions and answers
│   └── grocery_knowledge_base.csv   111 general food facts and agent rules
└── README.md
```

## View the page

Open `index.html` in a browser, or publish it with GitHub Pages:

1. Push this repo to GitHub.
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.

The site will be available at `https://<your-username>.github.io/<repo-name>/`.

## Train the agent (Jotform)

1. Open the agent in the Jotform AI Agent Builder.
2. Click **Train**, then **Knowledge Base**, then **Add Knowledge**, then **File**.
3. Upload one CSV, describe how the agent should use it, and save. Repeat for each file.

| File | Suggested instruction |
|---|---|
| `grocery_catalog.csv` | Use this as the only source for products, prices, sizes, stock, offers and allergens. Never guess. |
| `agent_qa_pairs.csv` | Example questions and the style of answers to give. Use the same tone and rules for similar questions. |
| `grocery_knowledge_base.csv` | General grocery knowledge and behaviour rules. Use for storage, cooking, substitutions and safety questions. |

If a CSV upload fails, try a PDF or the Question & Answer option instead.

## Before going live

- **Replace the placeholders** in `agent_qa_pairs.csv`. Items in square brackets, such as `[STORE_NAME]`, `[DELIVERY_CHARGE]`, `[REFUND_POLICY]` and `[SUPPORT_CONTACT]`, need your real details.
- **Check prices.** In `grocery_catalog.csv`, the `price_source` column shows which prices came from a BigBasket listing and which are estimates. Replace the estimates with your real prices.
- **Products and brands are sample data.** Replace them with your own range.
- **Allergen and nutrition entries are general guidance.** The agent should always tell customers to read the pack label and should not give medical advice.

## Customise

- The store name and text in `index.html` are placeholders. Change them to match your brand.
- The agent ID in the embed code belongs to your Jotform agent. Do not change it unless you create a new agent.
